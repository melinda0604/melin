# melin

Program C++ untuk memasukkan nilai dan menentukan predikat.

## Membuat EXE melalui GitHub Actions

1. Upload seluruh isi folder proyek ini ke repository GitHub pada branch `main`.
2. Buka tab **Actions** di repository.
3. Pilih workflow **Build Windows EXE**.
4. Jika workflow belum berjalan otomatis, pilih **Run workflow**.
5. Tunggu sampai proses selesai dengan status hijau (berhasil).
6. Buka hasil run tersebut dan cari bagian **Artifacts**.
7. Download `inputannilai-windows-exe`.
8. Ekstrak ZIP hasil download. Di dalamnya ada `inputannilai.exe`.

Workflow ini menggunakan compiler MSVC pada runner Windows GitHub.
